<?php
// Heading
$_['heading_title']    = 'Octemplates Авто-рекомендовані товари';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Налаштування успішно змінені!';
$_['text_edit']        = 'Налаштування модуля';
$_['text_success_cache']        = 'Кеш успішно очищений';
$_['text_cache']                = 'Видалити кеш';

// Entry
$_['entry_limit']      = 'Ліміт';
$_['entry_width']      = 'Ширина';
$_['entry_height']     = 'Висота';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас немає прав для управління даними модулем!';
$_['error_limit']      = 'Введіть ліміт товарів!';
$_['error_width']      = 'Введіть ширину зображення!';
$_['error_height']     = 'Введіть висоту зображення!';