<?php
// Heading
$_['heading_title']    = 'Octemplates - Авто-рекомендуемые товары';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Настройки модуля';
$_['text_success_cache']        = 'Кэш успешно очищен';
$_['text_cache']                = 'Удалить кэш';
// Entry
$_['entry_limit']      = 'Лимит';
$_['entry_width']      = 'Ширина';
$_['entry_height']     = 'Высота';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас нет прав для управления данным модулем!';
$_['error_limit']      = 'Введите лимит товаров!';
$_['error_width']      = 'Введите ширину изображения!';
$_['error_height']     = 'Введите высоту изображения!';